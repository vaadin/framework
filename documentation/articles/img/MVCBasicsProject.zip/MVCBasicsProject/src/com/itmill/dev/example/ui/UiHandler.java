package com.itmill.dev.example.ui;

import java.util.HashMap;

import com.itmill.dev.example.ui.component.Header;
import com.itmill.dev.example.ui.component.Menu;
import com.itmill.dev.example.ui.view.AbstractView;
import com.itmill.dev.example.ui.view.ChannelView;
import com.itmill.dev.example.ui.view.WelcomeView;
import com.itmill.dev.example.ui.view.UserView;
import com.itmill.toolkit.Application.UserChangeEvent;
import com.itmill.toolkit.Application.UserChangeListener;
import com.itmill.toolkit.ui.*;

public class UiHandler extends VerticalLayout implements UserChangeListener {

	// Portions of the application that exist at all times.
	private Header header;
	private WelcomeView defaultView;

	// The views that are shown to logged users.
	private UserView userView;
	private ChannelView javaView;
	private ChannelView ubuntuView;

	// Components shown to logged users.
	private Menu menu;
	private SplitPanel menusplit;

	// Used to keep track of the current main view.

	private HashMap<String, AbstractView> viewList = new HashMap<String, AbstractView>();

	/*
	 * Constructor of the handler. Creates and styles all default components.
	 * 
	 * @param window main window of the application
	 */
	public UiHandler(Window window) {

		header = new Header();
		defaultView = new WelcomeView();

		setSizeFull();
		setMargin(true);

		// Add the main components for the UI.

		addComponent(header);
		addComponent(defaultView);

		setComponentAlignment(header, Alignment.TOP_CENTER);
		setComponentAlignment(defaultView, Alignment.TOP_CENTER);

		setExpandRatio(defaultView, 1);
		this.setSpacing(true);
		window.setLayout(this);
		
	}

	/*
	 * All the UI logic in the event that a user logs in.
	 */
	public void userLoggedIn() {

		// initialization of the user specific portions of the UI and
		// add a split panel to differentiate between menu and main view.
		userView = new UserView();
		menu = new Menu();
		javaView = new ChannelView("#java");
		ubuntuView = new ChannelView("#ubuntu");

		// Hard code adding of the user specific views to the view list.
		viewList.put("#java", javaView);
		viewList.put("#ubuntu", ubuntuView);
		viewList.put("User View", userView);

		menusplit = new SplitPanel(SplitPanel.ORIENTATION_HORIZONTAL);

		// Adds the splitbar to the layout.
		addComponent(menusplit, 1);

		// Visual modifiers of the splitpanel.
		setExpandRatio(menusplit, 1);
		menusplit.setSplitPosition(200, SplitPanel.UNITS_PIXELS);

		// Remove the default view and show the user specifc one.
		removeComponent(defaultView);
		addComponent(userView);

		// Set the menu on the left side of the split.
		menusplit.setFirstComponent(menu);

		// Set the Welcome View on the right side.
		setMainView(userView);

		// Inform the different parts of the UI that the user has logged in.
		header.userLoggedIn();
		

		ExampleApplication.getProject().getMainWindow().showNotification(
				"Login Successful");

	}

	/*
	 * Reverts back to the default view and removes all the user specific
	 * content.
	 */
	public void userLoggedOut() {

		// If components exist.
		try {
			// Remove the split panel including menu and userView.
			removeComponent(menusplit);

			// Add the default view.
			addComponent(defaultView, 1);
			setExpandRatio(defaultView, 1);

			// Tell the other UI components that the user logged off.
			header.userLoggedOut();

		} catch (Exception e) {

		}
	}

	/*
	 * Updates the main view when the user clicks an item in the menu.
	 * 
	 * @param event Event
	 */
	public void switchView(String viewName) {
		setMainView(viewList.get(viewName));
	}

	/*
	 * Helper method for setting the main view.
	 * 
	 * @param c View that we want to display
	 */
	public void setMainView(AbstractView c) {

		menusplit.setSecondComponent(c);

	}

	/*
	 * Closes the view and removes it from the menu.
	 */
	public void closeCurrentView() throws Exception {

		// Remove the view from the view list.
		viewList.remove(menu.getTree().getValue().toString());
		setMainView(userView);
		menu.removeCurrentTreeSelection();

	}

	public void applicationUserChanged(UserChangeEvent event) {


				if (event.getNewUser() == null) {
					userLoggedOut();
				} else {
					userLoggedIn();
				}

	}

}

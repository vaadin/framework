package com.itmill.dev.example.ui.view;

import com.itmill.dev.example.ui.ExampleApplication;
import com.itmill.toolkit.ui.Alignment;
import com.itmill.toolkit.ui.Button;
import com.itmill.toolkit.ui.HorizontalLayout;
import com.itmill.toolkit.ui.Table;
import com.itmill.toolkit.ui.TextField;
import com.itmill.toolkit.ui.VerticalLayout;
import com.itmill.toolkit.ui.Label;
import com.itmill.toolkit.ui.Panel;
import com.itmill.toolkit.ui.Window;
import com.itmill.toolkit.ui.Button.ClickEvent;
import com.itmill.dev.example.ui.controller.ChannelController;

public class ChannelView extends AbstractView {

	protected Window confirm;
	private ChannelController controller;
	private String channelName = "";
	private TextField inputLine;

	// Table to hold the text
	private Table textTable;

	/*
	 * @param name Name of the channel we are creating
	 */
	public ChannelView(String name) {

		controller = new ChannelController();

		channelName = name;
		VerticalLayout layout = new VerticalLayout();

		// Create the visual components of the view.
		setSizeFull();
		setCompositionRoot(layout);

		layout.setHeight("100%");
		layout.setWidth("100%");
		layout.setSpacing(true);
		layout.setMargin(true);

		// Get the log container and add it to the view.
		textTable = new Table();
		textTable.setContainerDataSource(controller.getChannelLog(channelName));
		textTable.setCurrentPageFirstItemId(textTable.lastItemId());
		textTable.setSizeFull();
		textTable.setPageLength(0);
		textTable.setImmediate(true);

		textTable.setColumnWidth("timestamp", 80);

		layout.addComponent(textTable);

		// Button to close the view and remove it from the menu.
		final Button closeButton = new Button("Leave Channel",
				new Button.ClickListener() {
					public void buttonClick(ClickEvent event) {
						try {
							close();
						} catch (Exception e) {
						}

					}
				});

		layout.addComponent(closeButton);
		layout.setComponentAlignment(closeButton, Alignment.TOP_RIGHT);

		// Creates the panel into which the user can type the message.
		Panel inputPanel = createInputPanel();
		layout.addComponent(inputPanel);
		layout.setComponentAlignment(inputPanel, Alignment.MIDDLE_CENTER);

		layout.setExpandRatio(textTable, 1);

	}

	/*
	 * Close method from AbstractView.
	 * 
	 * @see ui.AbstractView#close()
	 */
	protected void close() throws Exception {
		HorizontalLayout bl = new HorizontalLayout();

		confirm = new Window("Confirmation");
		confirm.setModal(true);
		confirm.setReadOnly(true);
		VerticalLayout l = (VerticalLayout) confirm.getLayout();

		l.addComponent(new Label(
				"Are you sure you want to part from this channel?"));

		// Yes / No buttons

		Button yes = new Button("Yes", new Button.ClickListener() {
			public void buttonClick(ClickEvent event) {

				try {
					ExampleApplication.getProject().getUiHandler()
							.closeCurrentView();
					ExampleApplication.getProject().getMainWindow()
							.removeWindow(confirm);
				} catch (Exception e) {

					e.printStackTrace();
				}
			}

		});

		Button no = new Button("No", new Button.ClickListener() {
			public void buttonClick(ClickEvent event) {
				ExampleApplication.getProject().getMainWindow().removeWindow(
						confirm);
			}

		});

		bl.addComponent(yes);
		bl.addComponent(no);
		l.addComponent(bl);
		ExampleApplication.getProject().getMainWindow().addWindow(confirm);

	}

	/*
	 * User "write to channel" panel.
	 */
	private Panel createInputPanel() {

		inputLine = new TextField();
		inputLine.setValue("");
		Button submitButton;
		Panel panel;

		panel = new Panel();
		panel.setWidth("100%");

		HorizontalLayout layout = new HorizontalLayout();

		layout.setWidth("100%");

		submitButton = new Button("Submit", new Button.ClickListener() {
			public void buttonClick(ClickEvent event) {

				sendMessage();

			}
		});

		layout.addComponent(inputLine);
		layout.addComponent(submitButton);

		layout.setComponentAlignment(inputLine, Alignment.TOP_RIGHT);
		layout.setComponentAlignment(submitButton, Alignment.TOP_LEFT);
		inputLine.setWidth("100%");
		layout.setExpandRatio(inputLine, 1);

		panel.addComponent(layout);
		return panel;

	}

	/*
	 * When the user sends the message to the channel.
	 */
	public void sendMessage() {

		// Let the controller modify the current text on the inputline and
		// insert it into the channel text table.
		controller.writeToChannel(inputLine.getValue(), textTable);

		// Clear the input line.
		inputLine.setValue("");
	}

}

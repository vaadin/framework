package com.itmill.dev.example.data;

/*
 * Simple User ID class.
 */
public class User {

	private String firstname;
	private String lastname;
	
	public User(String first, String last){
		firstname = first;
		lastname = last;
	}
	
	public String getFirstName(){
		return firstname;
	}
	
	public String getLastName(){
		return lastname;
	}
}

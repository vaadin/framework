package com.itmill.dev.example.ui.view;

import com.itmill.toolkit.ui.*;

public class WelcomeView extends AbstractView {

	public WelcomeView() {

		setHeight("100%");

		VerticalLayout layout = new VerticalLayout();
		setCompositionRoot(layout);

		layout.setMargin(false);
		layout.setHeight("100%");

		// Main panel to hold information shown to the unlogged user.
		Panel panel = new Panel("Welcome to the Training Project.");
		panel.setSizeFull();
		panel.setStyleName("default-panel");

		VerticalLayout textLayout = new VerticalLayout();

		Label lbl = new Label(
				"Welcome to the training project by Sebastian Nyholm created for ItMill.");
		Label lbl2 = new Label(
				"The object of this project is to create a simple application involving few views and UI control logic using the ItMill Toolkit (tm) where coupling is minimal.");
		Label lbl3 = new Label(
				"This project gives one perspective how you do MVC in Toolkit application.");
		Label lbl4 = new Label("Please login using demo / demo.");

		textLayout.addComponent(lbl);
		textLayout.addComponent(lbl2);
		textLayout.addComponent(lbl3);
		textLayout.addComponent(lbl4);
		textLayout.setWidth("50%");
		textLayout.setHeight("100%");
		panel.addComponent(textLayout);

		layout.addComponent(panel);

	}

	/*
	 * Close method from AbstractView.
	 * 
	 * @see ui.AbstractView#close()
	 */
	protected void close() throws Exception {

	}

}
